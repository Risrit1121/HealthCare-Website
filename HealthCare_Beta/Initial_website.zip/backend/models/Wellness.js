import mongoose from 'mongoose';

const wellnessSchema = new mongoose.Schema({
  patientId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  date: {
    type: Date,
    default: Date.now
  },
  steps: {
    type: Number,
    default: 0,
    min: 0
  },
  heartRate: {
    type: Number,
    default: 0,
    min: 0
  },
  bloodPressure: {
    systolic: {
      type: Number,
      default: 0
    },
    diastolic: {
      type: Number,
      default: 0
    }
  },
  weight: {
    type: Number,
    default: 0,
    min: 0
  },
  height: {
    type: Number,
    default: 0,
    min: 0
  },
  caloriesBurned: {
    type: Number,
    default: 0,
    min: 0
  },
  sleepHours: {
    type: Number,
    default: 0,
    min: 0,
    max: 24
  },
  notes: {
    type: String,
    default: ''
  }
}, {
  timestamps: true
});

// Index for efficient queries
wellnessSchema.index({ patientId: 1, date: -1 });

const Wellness = mongoose.model('Wellness', wellnessSchema);

export default Wellness;



