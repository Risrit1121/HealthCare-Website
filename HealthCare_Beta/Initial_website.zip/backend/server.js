import express from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/users.js';
import wellnessRoutes from './routes/wellness.js';

dotenv.config();

const app = express();

// Middleware
// CORS configuration - allow frontend domains
const allowedOrigins = [
  'http://localhost:5173',
  'http://localhost:3000',
  process.env.FRONTEND_URL // Add your production frontend URL here
].filter(Boolean); // Remove undefined values

app.use(cors({
  origin: process.env.NODE_ENV === 'production' 
    ? allowedOrigins.length > 0 
      ? allowedOrigins 
      : '*' // Allow all in production if no specific URL set
    : 'http://localhost:5173', // Development
  credentials: true
}));
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/wellness', wellnessRoutes);

// Health check
app.get('/api/health', (req, res) => {
  res.json({ message: 'Healthcare Portal API is running' });
});

// Connect to MongoDB
const PORT = process.env.PORT || 5000;
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/healthcare-portal';

mongoose.connect(MONGODB_URI)
  .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
    process.exit(1);
  });

export default app;



