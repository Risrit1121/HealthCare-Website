import express from 'express';
import User from '../models/User.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Get all patients (for healthcare providers)
router.get('/patients', authenticate, authorize('healthcare_provider'), async (req, res) => {
  try {
    const patients = await User.find({ role: 'patient' })
      .select('-password')
      .sort({ createdAt: -1 });

    // Transform _id to id for consistency
    const transformedPatients = patients.map(patient => ({
      id: patient._id,
      name: patient.name,
      email: patient.email,
      phone: patient.phone,
      dateOfBirth: patient.dateOfBirth,
      address: patient.address,
      role: patient.role,
      createdAt: patient.createdAt
    }));

    res.json({ patients: transformedPatients });
  } catch (error) {
    console.error('Error fetching patients:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get single patient (for healthcare providers)
router.get('/patients/:id', authenticate, authorize('healthcare_provider'), async (req, res) => {
  try {
    const patient = await User.findById(req.params.id)
      .select('-password');

    if (!patient || patient.role !== 'patient') {
      return res.status(404).json({ message: 'Patient not found' });
    }

    // Transform _id to id for consistency
    res.json({
      patient: {
        id: patient._id,
        name: patient.name,
        email: patient.email,
        phone: patient.phone,
        dateOfBirth: patient.dateOfBirth,
        address: patient.address,
        role: patient.role,
        createdAt: patient.createdAt
      }
    });
  } catch (error) {
    console.error('Error fetching patient:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Update user profile
router.put('/profile', authenticate, async (req, res) => {
  try {
    const { name, phone, dateOfBirth, address, specialization, licenseNumber } = req.body;

    const updateData = {};
    if (name) updateData.name = name;
    if (phone) updateData.phone = phone;
    if (dateOfBirth) updateData.dateOfBirth = dateOfBirth;
    if (address) updateData.address = address;

    // Only allow healthcare providers to update these fields
    if (req.user.role === 'healthcare_provider') {
      if (specialization !== undefined) updateData.specialization = specialization;
      if (licenseNumber !== undefined) updateData.licenseNumber = licenseNumber;
    }

    const user = await User.findByIdAndUpdate(
      req.user._id,
      { $set: updateData },
      { new: true, runValidators: true }
    ).select('-password');

    res.json({
      message: 'Profile updated successfully',
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        phone: user.phone,
        dateOfBirth: user.dateOfBirth,
        address: user.address,
        specialization: user.specialization,
        licenseNumber: user.licenseNumber
      }
    });
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get user profile
router.get('/profile', authenticate, async (req, res) => {
  try {
    res.json({
      user: {
        id: req.user._id,
        name: req.user.name,
        email: req.user.email,
        role: req.user.role,
        phone: req.user.phone,
        dateOfBirth: req.user.dateOfBirth,
        address: req.user.address,
        specialization: req.user.specialization,
        licenseNumber: req.user.licenseNumber
      }
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

export default router;



