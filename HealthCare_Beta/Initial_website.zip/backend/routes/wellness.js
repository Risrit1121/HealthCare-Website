import express from 'express';
import Wellness from '../models/Wellness.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// Get wellness data for current patient
router.get('/my-wellness', authenticate, authorize('patient'), async (req, res) => {
  try {
    const wellnessData = await Wellness.find({ patientId: req.user._id })
      .sort({ date: -1 })
      .limit(30); // Get last 30 entries

    res.json({ wellnessData });
  } catch (error) {
    console.error('Error fetching wellness data:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get latest wellness data for current patient
router.get('/my-wellness/latest', authenticate, authorize('patient'), async (req, res) => {
  try {
    const latestWellness = await Wellness.findOne({ patientId: req.user._id })
      .sort({ date: -1 });

    if (!latestWellness) {
      return res.json({ wellness: null });
    }

    res.json({ wellness: latestWellness });
  } catch (error) {
    console.error('Error fetching latest wellness data:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Create or update wellness data (for patients)
router.post('/my-wellness', authenticate, authorize('patient'), async (req, res) => {
  try {
    const {
      date,
      steps,
      heartRate,
      bloodPressure,
      weight,
      height,
      caloriesBurned,
      sleepHours,
      notes
    } = req.body;

    const wellnessData = {
      patientId: req.user._id,
      date: date ? new Date(date) : new Date(),
      steps: steps || 0,
      heartRate: heartRate || 0,
      bloodPressure: bloodPressure || { systolic: 0, diastolic: 0 },
      weight: weight || 0,
      height: height || 0,
      caloriesBurned: caloriesBurned || 0,
      sleepHours: sleepHours || 0,
      notes: notes || ''
    };

    // Check if entry exists for today
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const endOfDay = new Date(today);
    endOfDay.setHours(23, 59, 59, 999);

    const existingEntry = await Wellness.findOne({
      patientId: req.user._id,
      date: { $gte: today, $lte: endOfDay }
    });

    let wellness;
    if (existingEntry) {
      // Update existing entry
      wellness = await Wellness.findByIdAndUpdate(
        existingEntry._id,
        { $set: wellnessData },
        { new: true, runValidators: true }
      );
    } else {
      // Create new entry
      wellness = new Wellness(wellnessData);
      await wellness.save();
    }

    res.status(201).json({
      message: 'Wellness data saved successfully',
      wellness
    });
  } catch (error) {
    console.error('Error saving wellness data:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get wellness data for a specific patient (for healthcare providers)
router.get('/patient/:patientId', authenticate, authorize('healthcare_provider'), async (req, res) => {
  try {
    const wellnessData = await Wellness.find({ patientId: req.params.patientId })
      .sort({ date: -1 })
      .limit(30);

    res.json({ wellnessData });
  } catch (error) {
    console.error('Error fetching patient wellness data:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

// Get latest wellness data for a specific patient (for healthcare providers)
router.get('/patient/:patientId/latest', authenticate, authorize('healthcare_provider'), async (req, res) => {
  try {
    const latestWellness = await Wellness.findOne({ patientId: req.params.patientId })
      .sort({ date: -1 });

    if (!latestWellness) {
      return res.json({ wellness: null });
    }

    res.json({ wellness: latestWellness });
  } catch (error) {
    console.error('Error fetching latest patient wellness data:', error);
    res.status(500).json({ message: 'Server error', error: error.message });
  }
});

export default router;



